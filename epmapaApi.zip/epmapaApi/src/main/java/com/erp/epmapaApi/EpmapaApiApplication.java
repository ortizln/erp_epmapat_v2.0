package com.erp.epmapaApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpmapaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpmapaApiApplication.class, args);
	}

}
