package com.erp.epmapaApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpmapaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
